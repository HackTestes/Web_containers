#include <iostream>

int main()
{
    std::cout << "Compilado!\n";
    return 0;
}

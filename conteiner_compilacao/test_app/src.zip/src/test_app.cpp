#include <iostream>

int main()
{
    std::cout << "Compilado!";
    return 0;
}